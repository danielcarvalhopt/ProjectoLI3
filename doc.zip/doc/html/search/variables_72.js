var searchData=
[
  ['r',['r',['../structTree.html#ac585871877cc6723bb466baec6afaaaa',1,'Tree']]]
];
