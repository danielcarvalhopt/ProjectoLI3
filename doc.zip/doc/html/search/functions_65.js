var searchData=
[
  ['editaligacaoinput',['editaligacaoinput',['../dados_8c.html#aa12f90de3f4db968ebd7550f9685dcf9',1,'editaligacaoinput(TabelaHashPTR localidades):&#160;dados.c'],['../dados_8h.html#aa12f90de3f4db968ebd7550f9685dcf9',1,'editaligacaoinput(TabelaHashPTR localidades):&#160;dados.c']]]
];
