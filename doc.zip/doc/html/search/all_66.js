var searchData=
[
  ['freeligacaoida',['freeLigacaoIda',['../dados_8c.html#a0f80e5e67a33311de56c39ed57b03799',1,'freeLigacaoIda(LigacoesidaPTR ligacao):&#160;dados.c'],['../dados_8h.html#a0f80e5e67a33311de56c39ed57b03799',1,'freeLigacaoIda(LigacoesidaPTR ligacao):&#160;dados.c']]],
  ['freeligacaovinda',['freeLigacaoVinda',['../dados_8c.html#a68588264259148840ac975960ad089bb',1,'freeLigacaoVinda(LigacoesvindaPTR ligacao):&#160;dados.c'],['../dados_8h.html#a68588264259148840ac975960ad089bb',1,'freeLigacaoVinda(LigacoesvindaPTR ligacao):&#160;dados.c']]],
  ['freelocalidade',['freeLocalidade',['../dados_8c.html#a8c5f595a85be49338af0b584df250b20',1,'freeLocalidade(LocalidadePTR localidade):&#160;dados.c'],['../dados_8h.html#a8c5f595a85be49338af0b584df250b20',1,'freeLocalidade(LocalidadePTR localidade):&#160;dados.c']]],
  ['func_5fcompare',['func_compare',['../structMainList.html#a76c37901ee912183c39741763e5df108',1,'MainList']]]
];
