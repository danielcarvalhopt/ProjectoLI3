var searchData=
[
  ['ligacoesida',['Ligacoesida',['../structLigacoesida.html',1,'']]],
  ['ligacoesvinda',['Ligacoesvinda',['../structLigacoesvinda.html',1,'']]],
  ['linkedlist',['linkedList',['../structlinkedList.html',1,'']]],
  ['localidade',['Localidade',['../structLocalidade.html',1,'']]]
];
