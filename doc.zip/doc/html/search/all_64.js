var searchData=
[
  ['dados_2ec',['dados.c',['../dados_8c.html',1,'']]],
  ['dados_2eh',['dados.h',['../dados_8h.html',1,'']]],
  ['datahora',['datahora',['../structServico.html#a1bab7ef602693b749fb881aa1d28573e',1,'Servico']]],
  ['deserialize',['deserialize',['../serial_8c.html#af3a69f93a633813b0614e71a6a811601',1,'deserialize(MainTreePt *camioes, int(*comparaCamioes[DIM])(void *, void *), MainTreePt *clientes, int(*comparaClientes[DIM])(void *, void *), TabelaHashPTR *localidades, int(*comparaLocalidades)(void *, void *), int(*hash_function)(void *, int)):&#160;serial.c'],['../serial_8h.html#a52313c173df52a16301713e5ecdf2f84',1,'deserialize(MainTreePt *camioes, int(*comparaCamioes[DIM])(void *, void *), MainTreePt *clientes, int(*comparaClientes[DIM])(void *, void *), TabelaHashPTR *localidades, int(*func_compare)(void *, void *), int(*hash_function)(void *, int)):&#160;serial.c']]],
  ['destino',['destino',['../structServico.html#a122131932f18a84beaee1a5514ffa8e1',1,'Servico']]],
  ['dim',['DIM',['../mod__avl__n__dimensional_8h.html#ac25189db92959bff3c6c2adf4c34b50a',1,'mod_avl_n_dimensional.h']]],
  ['diminuitabelahash',['diminuiTabelaHash',['../mod__tabela__hash_8c.html#a6dec97c331e3d810c052a4b6bac6bf05',1,'diminuiTabelaHash(TabelaHashPTR table):&#160;mod_tabela_hash.c'],['../mod__tabela__hash_8h.html#a6dec97c331e3d810c052a4b6bac6bf05',1,'diminuiTabelaHash(TabelaHashPTR table):&#160;mod_tabela_hash.c']]],
  ['distancia',['distancia',['../structLigacoesida.html#a9d1f93083d4abf41c37d7f1e66b6758f',1,'Ligacoesida']]]
];
