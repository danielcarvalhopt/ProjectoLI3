var searchData=
[
  ['dados_2ec',['dados.c',['../dados_8c.html',1,'']]],
  ['dados_2eh',['dados.h',['../dados_8h.html',1,'']]],
  ['dim',['DIM',['../mod__avl__n__dimensional_8h.html#ac25189db92959bff3c6c2adf4c34b50a',1,'mod_avl_n_dimensional.h']]],
  ['distancia',['distancia',['../structLigacoesida.html#aa53cc6909f9536b91164d0e3e4817e21',1,'Ligacoesida']]]
];
