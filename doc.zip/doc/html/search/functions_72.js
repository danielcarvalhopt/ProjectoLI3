var searchData=
[
  ['readdouble',['readDouble',['../input_8c.html#a840ea5c01770156bd51bdb9f65f44e30',1,'readDouble():&#160;input.c'],['../input_8h.html#a840ea5c01770156bd51bdb9f65f44e30',1,'readDouble():&#160;input.c']]],
  ['readint',['readInt',['../input_8c.html#ac4dc9964d286ddbbd2a108991190d39d',1,'readInt():&#160;input.c'],['../input_8h.html#ac4dc9964d286ddbbd2a108991190d39d',1,'readInt():&#160;input.c']]],
  ['readstr',['readStr',['../input_8c.html#ab3bfa5385835bf501eab85d9c8fcf46c',1,'readStr(char *ptr):&#160;input.c'],['../input_8h.html#ab3bfa5385835bf501eab85d9c8fcf46c',1,'readStr(char *ptr):&#160;input.c']]],
  ['readuint',['readUInt',['../input_8c.html#abdea32bc22f0f024a3568a858556edf2',1,'readUInt():&#160;input.c'],['../input_8h.html#abdea32bc22f0f024a3568a858556edf2',1,'readUInt():&#160;input.c']]],
  ['removeligacaoinput',['removeligacaoinput',['../dados_8c.html#a23a8fc519adf2cf3bffbefda58f8a489',1,'removeligacaoinput(TabelaHashPTR table):&#160;dados.c'],['../dados_8h.html#a23a8fc519adf2cf3bffbefda58f8a489',1,'removeligacaoinput(TabelaHashPTR table):&#160;dados.c']]],
  ['removerligacao',['removerligacao',['../dados_8c.html#a0e54c4e1458bab50961b2dc1b683c95c',1,'removerligacao(TabelaHashPTR table, char *nomeorigem, char *nomedestino):&#160;dados.c'],['../dados_8h.html#a0e54c4e1458bab50961b2dc1b683c95c',1,'removerligacao(TabelaHashPTR table, char *nomeorigem, char *nomedestino):&#160;dados.c']]],
  ['removerlocalidade',['removerlocalidade',['../dados_8c.html#a7732b6504d86c2c1231d59df0e2c3164',1,'removerlocalidade(TabelaHashPTR table, char *nome):&#160;dados.c'],['../dados_8h.html#a7732b6504d86c2c1231d59df0e2c3164',1,'removerlocalidade(TabelaHashPTR table, char *nome):&#160;dados.c']]]
];
