var searchData=
[
  ['lerstr',['lerStr',['../input_8c.html#a0d850cfd2e2a21857dc404c546704108',1,'lerStr(char **ptr):&#160;input.c'],['../input_8h.html#a0d850cfd2e2a21857dc404c546704108',1,'lerStr(char **ptr):&#160;input.c']]]
];
