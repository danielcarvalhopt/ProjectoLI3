var searchData=
[
  ['lerstr',['lerStr',['../input_8c.html#aef681a09c440617a8146d73a3495282f',1,'lerStr(char *ptr):&#160;input.c'],['../input_8h.html#aef681a09c440617a8146d73a3495282f',1,'lerStr(char *ptr):&#160;input.c']]]
];
