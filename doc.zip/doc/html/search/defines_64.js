var searchData=
[
  ['desconhecido',['DESCONHECIDO',['../mod__dijkstra_8h.html#ae7286aace4c6df8caa3d9cc50e487d80',1,'DESCONHECIDO():&#160;mod_dijkstra.h'],['../mod__graph_8h.html#ae7286aace4c6df8caa3d9cc50e487d80',1,'DESCONHECIDO():&#160;mod_graph.h']]],
  ['dim',['DIM',['../mod__avl__n__dimensional_8h.html#ac25189db92959bff3c6c2adf4c34b50a',1,'mod_avl_n_dimensional.h']]]
];
