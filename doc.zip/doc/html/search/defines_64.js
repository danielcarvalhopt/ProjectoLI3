var searchData=
[
  ['dim',['DIM',['../mod__avl__n__dimensional_8h.html#ac25189db92959bff3c6c2adf4c34b50a',1,'mod_avl_n_dimensional.h']]]
];
