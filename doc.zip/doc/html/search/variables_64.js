var searchData=
[
  ['datahora',['datahora',['../structServico.html#a1bab7ef602693b749fb881aa1d28573e',1,'Servico']]],
  ['destino',['destino',['../structServico.html#a122131932f18a84beaee1a5514ffa8e1',1,'Servico']]],
  ['distancia',['distancia',['../structLigacoesida.html#aa53cc6909f9536b91164d0e3e4817e21',1,'Ligacoesida']]]
];
