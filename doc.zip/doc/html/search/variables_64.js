var searchData=
[
  ['distancia',['distancia',['../structLigacoesida.html#aa53cc6909f9536b91164d0e3e4817e21',1,'Ligacoesida']]]
];
