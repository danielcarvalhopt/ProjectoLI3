var searchData=
[
  ['datahora',['datahora',['../structServico.html#a1bab7ef602693b749fb881aa1d28573e',1,'Servico']]],
  ['destino',['destino',['../structServico.html#a122131932f18a84beaee1a5514ffa8e1',1,'Servico']]],
  ['distancia',['distancia',['../structLigacoesida.html#a9d1f93083d4abf41c37d7f1e66b6758f',1,'Ligacoesida::distancia()'],['../structGraphElem.html#a0a65db42ec7aa4d35fc0ce7f7b8dbf08',1,'GraphElem::distancia()']]]
];
