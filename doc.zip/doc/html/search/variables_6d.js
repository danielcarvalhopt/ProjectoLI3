var searchData=
[
  ['matricula',['matricula',['../structCamiao.html#a4411c3097d25d0dfad0b4b13d030a929',1,'Camiao']]],
  ['morada',['morada',['../structCliente.html#aeb21328e21f4564b38f3f2304ff14a78',1,'Cliente']]]
];
