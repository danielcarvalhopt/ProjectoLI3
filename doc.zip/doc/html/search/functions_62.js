var searchData=
[
  ['buildpathgraph',['buildPathGraph',['../mod__graph_8c.html#a1774794189003ed3f62a467b57cf1890',1,'buildPathGraph(GraphPTR graph, LigacoesidaPTR ligacao, GraphElemPTR vertex, int naOrla):&#160;mod_graph.c'],['../mod__graph_8h.html#a1774794189003ed3f62a467b57cf1890',1,'buildPathGraph(GraphPTR graph, LigacoesidaPTR ligacao, GraphElemPTR vertex, int naOrla):&#160;mod_graph.c']]]
];
