var searchData=
[
  ['elems',['elems',['../structMainList.html#a548dc650a76e1ee3c43388aca426806a',1,'MainList']]],
  ['extdata',['extdata',['../structlinkedList.html#aa3a0dd765ad0a60f505ada7f4c2cb75a',1,'linkedList']]]
];
