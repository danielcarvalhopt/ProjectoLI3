var searchData=
[
  ['editaligacaoinput',['editaligacaoinput',['../dados_8c.html#aa12f90de3f4db968ebd7550f9685dcf9',1,'editaligacaoinput(TabelaHashPTR localidades):&#160;dados.c'],['../dados_8h.html#aa12f90de3f4db968ebd7550f9685dcf9',1,'editaligacaoinput(TabelaHashPTR localidades):&#160;dados.c']]],
  ['elems',['elems',['../structMainList.html#a548dc650a76e1ee3c43388aca426806a',1,'MainList']]],
  ['extdata',['extdata',['../structlinkedList.html#aa3a0dd765ad0a60f505ada7f4c2cb75a',1,'linkedList']]]
];
