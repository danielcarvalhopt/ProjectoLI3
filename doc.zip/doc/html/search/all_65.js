var searchData=
[
  ['editaligacaoinput',['editaligacaoinput',['../input_8c.html#aa12f90de3f4db968ebd7550f9685dcf9',1,'editaligacaoinput(TabelaHashPTR localidades):&#160;input.c'],['../input_8h.html#aa12f90de3f4db968ebd7550f9685dcf9',1,'editaligacaoinput(TabelaHashPTR localidades):&#160;input.c']]],
  ['elems',['elems',['../structMainList.html#a548dc650a76e1ee3c43388aca426806a',1,'MainList']]],
  ['error',['Error',['../structError.html',1,'']]],
  ['error_5fcode',['error_code',['../structError.html#a6fcaab2c5811f09ff195d849dc3b54ce',1,'Error']]],
  ['error_5fliglocexist',['ERROR_LIGLOCEXIST',['../mod__error_8h.html#a0b77e79643588e7605bb113e7e7630ea',1,'mod_error.h']]],
  ['error_5fliglocnotexist',['ERROR_LIGLOCNOTEXIST',['../mod__error_8h.html#a0812250be583ed9f777f069ac9a649e3',1,'mod_error.h']]],
  ['error_5flocexist',['ERROR_LOCEXIST',['../mod__error_8h.html#afea03014f17a92283077b27b11aaa93a',1,'mod_error.h']]],
  ['error_5flocnotexist',['ERROR_LOCNOTEXIST',['../mod__error_8h.html#a4fb2282b406f65537a345f08a3c851cb',1,'mod_error.h']]],
  ['error_5fmemaloc',['ERROR_MEMALOC',['../mod__error_8h.html#af21f7219cb18029ad4d50e44abfb87fb',1,'mod_error.h']]],
  ['error_5fnocamloc',['ERROR_NOCAMLOC',['../mod__error_8h.html#af5c6ec07598a13054a02209817743cea',1,'mod_error.h']]],
  ['error_5fnoligs',['ERROR_NOLIGS',['../mod__error_8h.html#a6a2cd941a41759f816d3220118b2dcde',1,'mod_error.h']]],
  ['error_5fsuccess',['ERROR_SUCCESS',['../mod__error_8h.html#aea0ae801b7d25c979655a7eb20d034af',1,'mod_error.h']]],
  ['errormessage',['errorMessage',['../mod__error_8c.html#aad8b301c992289a22d078ef770704dc8',1,'errorMessage(int error_code):&#160;mod_error.c'],['../mod__error_8h.html#aad8b301c992289a22d078ef770704dc8',1,'errorMessage(int error_code):&#160;mod_error.c']]],
  ['errors',['errors',['../mod__error_8c.html#a86e2238eac2e07bd0f14c2af519c570a',1,'mod_error.c']]],
  ['estado',['estado',['../structGraphElem.html#a6bfc3f0757be7a03ba4699d14e9e3f76',1,'GraphElem']]],
  ['extdata',['extdata',['../structlinkedList.html#aa3a0dd765ad0a60f505ada7f4c2cb75a',1,'linkedList']]]
];
