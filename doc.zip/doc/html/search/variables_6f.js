var searchData=
[
  ['operativesystem',['operativeSystem',['../utils_8c.html#a05e6518ba04ff9f12a048253ec31f5d2',1,'utils.c']]],
  ['origem',['origem',['../structServico.html#af4f704fbdde1be12afd0dd6f6b429ba7',1,'Servico']]]
];
