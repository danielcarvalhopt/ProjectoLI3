var searchData=
[
  ['servico',['Servico',['../structServico.html',1,'']]],
  ['ssamplelocalidades',['sSampleLocalidades',['../structsSampleLocalidades.html',1,'']]],
  ['statslocalidade',['StatsLocalidade',['../structStatsLocalidade.html',1,'']]]
];
