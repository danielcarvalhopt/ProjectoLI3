var searchData=
[
  ['nelems',['nelems',['../structMainList.html#a2c214e2d8174c5b72c543da20fc0d755',1,'MainList::nelems()'],['../structTabelaHash.html#a6c824961baffd816f3992a879e3a039c',1,'TabelaHash::nelems()']]],
  ['nif',['nif',['../structCliente.html#a6a2d2cb67fac7da3f21cf2f73bcff2f9',1,'Cliente']]],
  ['node',['node',['../structTree.html#a1922494df9f108d059e409ef1ef5e851',1,'Tree']]],
  ['nodos',['nodos',['../structMainTree.html#aa58e78823b6cff0b3b96226ee414934b',1,'MainTree']]],
  ['nome',['nome',['../structCliente.html#af5d994105d3f3d7197ebf9c6fc1b62c1',1,'Cliente::nome()'],['../structLigacoesida.html#aa47bd75d72f292e0963aa36cb7cf26b0',1,'Ligacoesida::nome()'],['../structLigacoesvinda.html#add7f08b0e13ab24b7c1df3827deea5fd',1,'Ligacoesvinda::nome()'],['../structLocalidade.html#aa3d0e771bcedc32b46cb3f7eeaba02c9',1,'Localidade::nome()'],['../structsSampleLocalidades.html#a2cba0917fd3e7f76a16909b9cdbe45e3',1,'sSampleLocalidades::nome()'],['../structGraphElem.html#a3ad9eff85a8e40fcabc3c677017eee8f',1,'GraphElem::nome()']]],
  ['nomeanterior',['nomeAnterior',['../structGraphElem.html#ada7d0b31ca3035eb5eb461bfb1d5b612',1,'GraphElem']]]
];
