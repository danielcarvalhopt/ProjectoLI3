var searchData=
[
  ['serial_2ec',['serial.c',['../serial_8c.html',1,'']]],
  ['serial_2eh',['serial.h',['../serial_8h.html',1,'']]],
  ['serial_5fcamiao',['serial_camiao',['../serial_8c.html#ade9cff9103a95bb6c1bbbfc0a3458995',1,'serial.c']]],
  ['serial_5fcamiaorec',['serial_camiaoRec',['../serial_8c.html#a0bf747b81b58fe974ac6b45bcd94605f',1,'serial.c']]],
  ['serial_5fcliente',['serial_cliente',['../serial_8c.html#a3a417965ef99a804c2199485947560dd',1,'serial.c']]],
  ['serial_5fclienterec',['serial_clienteRec',['../serial_8c.html#a189372a27050d7b5655a67a23dc46711',1,'serial.c']]],
  ['serialize',['serialize',['../serial_8c.html#a46c1ab8a3903cfe247ebb5699fa22706',1,'serialize(TabelaHashPTR tabela, MainTreePt camioes, MainTreePt clientes):&#160;serial.c'],['../serial_8h.html#a46c1ab8a3903cfe247ebb5699fa22706',1,'serialize(TabelaHashPTR tabela, MainTreePt camioes, MainTreePt clientes):&#160;serial.c']]],
  ['servico',['Servico',['../structServico.html',1,'']]],
  ['servicos',['servicos',['../structCliente.html#a8910d65a3b960b8e739174551e57679b',1,'Cliente']]],
  ['startcells',['startcells',['../structTabelaHash.html#a63632b89faabc1b08b9b40b97bd1e424',1,'TabelaHash']]]
];
