var searchData=
[
  ['searchgraphelemaux',['searchGraphElemAux',['../mod__graph_8c.html#a7f120ce17d995fcad2af393a72b0f81a',1,'mod_graph.c']]],
  ['serial_2ec',['serial.c',['../serial_8c.html',1,'']]],
  ['serial_2eh',['serial.h',['../serial_8h.html',1,'']]],
  ['serial_5fcamiao',['serial_camiao',['../serial_8c.html#ab5e50bead65b2f14c94aec0989befe24',1,'serial_camiao(MainTreePt thisMainTree, FILE *file):&#160;serial.c'],['../serial_8h.html#ab5e50bead65b2f14c94aec0989befe24',1,'serial_camiao(MainTreePt thisMainTree, FILE *file):&#160;serial.c']]],
  ['serial_5fcamiaorec',['serial_camiaoRec',['../serial_8c.html#afc1053423bc2af5fa743505bdb6f4742',1,'serial_camiaoRec(TreePt thisTree, FILE *file):&#160;serial.c'],['../serial_8h.html#afc1053423bc2af5fa743505bdb6f4742',1,'serial_camiaoRec(TreePt thisTree, FILE *file):&#160;serial.c']]],
  ['serial_5fcliente',['serial_cliente',['../serial_8c.html#a69b3873b82c03efad4cce0e9ce32a3c0',1,'serial_cliente(MainTreePt thisMainTree, FILE *file):&#160;serial.c'],['../serial_8h.html#a69b3873b82c03efad4cce0e9ce32a3c0',1,'serial_cliente(MainTreePt thisMainTree, FILE *file):&#160;serial.c']]],
  ['serial_5fclienterec',['serial_clienteRec',['../serial_8c.html#ae42af9a483ae39107dbf459196bcf7ea',1,'serial_clienteRec(TreePt thisTree, FILE *file):&#160;serial.c'],['../serial_8h.html#ae42af9a483ae39107dbf459196bcf7ea',1,'serial_clienteRec(TreePt thisTree, FILE *file):&#160;serial.c']]],
  ['serialize',['serialize',['../serial_8c.html#a46c1ab8a3903cfe247ebb5699fa22706',1,'serialize(TabelaHashPTR tabela, MainTreePt camioes, MainTreePt clientes):&#160;serial.c'],['../serial_8h.html#a46c1ab8a3903cfe247ebb5699fa22706',1,'serialize(TabelaHashPTR tabela, MainTreePt camioes, MainTreePt clientes):&#160;serial.c']]],
  ['servico',['Servico',['../structServico.html',1,'']]],
  ['servicos',['servicos',['../structCliente.html#a8910d65a3b960b8e739174551e57679b',1,'Cliente']]],
  ['ssamplelocalidades',['sSampleLocalidades',['../structsSampleLocalidades.html',1,'']]]
];
