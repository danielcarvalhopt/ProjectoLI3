var searchData=
[
  ['novaescolha',['novaEscolha',['../menu_8c.html#a57384f807a4e64709ef4182c75941d93',1,'menu.c']]],
  ['novastring',['novaString',['../serial_8c.html#a194821c5d395ab57946548bd2ef657c2',1,'serial.c']]]
];
