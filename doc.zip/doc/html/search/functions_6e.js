var searchData=
[
  ['novaescolha',['novaEscolha',['../menu_8c.html#a57384f807a4e64709ef4182c75941d93',1,'menu.c']]],
  ['novastring',['novaString',['../serial_8c.html#a937936cb92dd81c774167093f080b246',1,'novaString(unsigned int n):&#160;serial.c'],['../serial_8h.html#a937936cb92dd81c774167093f080b246',1,'novaString(unsigned int n):&#160;serial.c']]]
];
