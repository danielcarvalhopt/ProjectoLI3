var searchData=
[
  ['tree_5fapplytoallordered',['tree_applyToAllOrdered',['../mod__avl__n__dimensional_8c.html#ace618d84c65154aff3db4827b6f0d80c',1,'tree_applyToAllOrdered(MainTreePt thisMainTree, int thisDim, void(*func)(void *)):&#160;mod_avl_n_dimensional.c'],['../mod__avl__n__dimensional_8h.html#ace618d84c65154aff3db4827b6f0d80c',1,'tree_applyToAllOrdered(MainTreePt thisMainTree, int thisDim, void(*func)(void *)):&#160;mod_avl_n_dimensional.c']]],
  ['tree_5fapplytoallorderedrec',['tree_applyToAllOrderedRec',['../mod__avl__n__dimensional_8c.html#a7bb8b6d21daf67ffc4e66e30aa6776f4',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fdisconnecttree',['tree_disconnectTree',['../mod__avl__n__dimensional_8c.html#aee6c3d92974e70a42d084974e613cd47',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fdispose',['tree_dispose',['../mod__avl__n__dimensional_8c.html#a7cbab28d4a578b70dee8558141643657',1,'tree_dispose(MainTreePt *thisMainTree):&#160;mod_avl_n_dimensional.c'],['../mod__avl__n__dimensional_8h.html#a7cbab28d4a578b70dee8558141643657',1,'tree_dispose(MainTreePt *thisMainTree):&#160;mod_avl_n_dimensional.c']]],
  ['tree_5fdisposerec',['tree_disposeRec',['../mod__avl__n__dimensional_8c.html#acbe28e4a858eccbcfa223417dd0525b9',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fdoublerotateleftright',['tree_doubleRotateLeftRight',['../mod__avl__n__dimensional_8c.html#a8c3bc98bcf67a67dec25a5da6cf8ef73',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fdoublerotaterightleft',['tree_doubleRotateRightLeft',['../mod__avl__n__dimensional_8c.html#aef340b3ac683c22730a646d986e16264',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fgetelem',['tree_getElem',['../mod__avl__n__dimensional_8c.html#ab08254ef998ed75156fbe89e3efd7121',1,'tree_getElem(TreePt thisTreePt):&#160;mod_avl_n_dimensional.c'],['../mod__avl__n__dimensional_8h.html#ab08254ef998ed75156fbe89e3efd7121',1,'tree_getElem(TreePt thisTreePt):&#160;mod_avl_n_dimensional.c']]],
  ['tree_5fgetheight',['tree_getHeight',['../mod__avl__n__dimensional_8c.html#a446d21abf09a01dba9153beafde24f58',1,'mod_avl_n_dimensional.c']]],
  ['tree_5finsert',['tree_insert',['../mod__avl__n__dimensional_8c.html#a0420e1fde3241215a77654fcc66df9ce',1,'tree_insert(MainTreePt thisMainTree, void *node):&#160;mod_avl_n_dimensional.c'],['../mod__avl__n__dimensional_8h.html#a0420e1fde3241215a77654fcc66df9ce',1,'tree_insert(MainTreePt thisMainTree, void *node):&#160;mod_avl_n_dimensional.c']]],
  ['tree_5finsertrec',['tree_insertRec',['../mod__avl__n__dimensional_8c.html#a4f461f7d4a69e2d5f3e39934d3008452',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fmaintain',['tree_maintain',['../mod__avl__n__dimensional_8c.html#a30065284bb80dee0b971f9222bb51ed3',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fnew',['tree_new',['../mod__avl__n__dimensional_8c.html#a4d96b9764a55e3931f9fdc8dd8a418bc',1,'tree_new(int(*compare[DIM])(void *, void *)):&#160;mod_avl_n_dimensional.c'],['../mod__avl__n__dimensional_8h.html#a4d96b9764a55e3931f9fdc8dd8a418bc',1,'tree_new(int(*compare[DIM])(void *, void *)):&#160;mod_avl_n_dimensional.c']]],
  ['tree_5fpushup',['tree_pushUp',['../mod__avl__n__dimensional_8c.html#a61f79d848d6520a8c19b34bb304ae5cd',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fremove',['tree_remove',['../mod__avl__n__dimensional_8c.html#af73e9b01b0a262c4b891a57753546e8f',1,'tree_remove(MainTreePt thisMainTreePt, void *node, int dim):&#160;mod_avl_n_dimensional.c'],['../mod__avl__n__dimensional_8h.html#af73e9b01b0a262c4b891a57753546e8f',1,'tree_remove(MainTreePt thisMainTreePt, void *node, int dim):&#160;mod_avl_n_dimensional.c']]],
  ['tree_5fsearch',['tree_search',['../mod__avl__n__dimensional_8c.html#ae6cfef96f291c43b350a312888757a0d',1,'tree_search(MainTreePt thisMainTree, void *node, int thisDim):&#160;mod_avl_n_dimensional.c'],['../mod__avl__n__dimensional_8h.html#ae6cfef96f291c43b350a312888757a0d',1,'tree_search(MainTreePt thisMainTree, void *node, int thisDim):&#160;mod_avl_n_dimensional.c']]],
  ['tree_5fsearchrec',['tree_searchRec',['../mod__avl__n__dimensional_8c.html#ae62240d8d10c60a041cd2bd61a9a1bf5',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fsearchtreetodisconnect',['tree_searchTreeToDisconnect',['../mod__avl__n__dimensional_8c.html#ac354ce60448462b80f1786ef043a9ac2',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fsinglerotateleft',['tree_singleRotateLeft',['../mod__avl__n__dimensional_8c.html#a642324442f25cbe6bde56053af5b5abc',1,'mod_avl_n_dimensional.c']]],
  ['tree_5fsinglerotateright',['tree_singleRotateRight',['../mod__avl__n__dimensional_8c.html#ae111eccaa9170a011e697a9df3d4b929',1,'mod_avl_n_dimensional.c']]]
];
